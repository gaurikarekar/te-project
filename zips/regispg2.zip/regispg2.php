<?php
$servername = "localhost";
$username = "root";
$password = "password";
$dbname = "registration";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}



 if ($_POST['typeofstb'] == 1) {
    $typeofstb = 1;
 }
 if ($_POST['typeofstb'] == 2) {
    $typeofstb = 2;
 }
 if ($_POST['typeofstb'] == 3) {
    $typeofstb = 3;
 }



 if ($_POST['noofcon'] == 1) {
     $noofcon = 1;
 }
 if ($_POST['noofcon'] == 2) {
    $noofcon = 2;
 }
 if ($_POST['noofcon'] == 3) {
     $noofcon = 3;
 }


if ($_POST['installation'] == 1) {
    $installation = 1;
}
if ($_POST['installation'] == 2) {
   $installation = 2;
}
if ($_POST['installation'] == 3) {
   $installation = 3;
}

$mobile = 99;

$updatesql = "UPDATE customer SET typeofstb = '".$typeofstb."' WHERE mobile = 44";
$updatesql = "UPDATE customer SET noofcon = '".$noofcon."' WHERE mobile = 44";
$updatesql = "UPDATE customer SET installation = '".$installation."' WHERE mobile = 44";

$updateresult = $conn->query($updatesql);

?>